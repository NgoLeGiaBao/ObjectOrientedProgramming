public enum VegetableType {
    CABBAGE, CARROT, PUMPKIN
} 