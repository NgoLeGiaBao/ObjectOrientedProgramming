public interface Vegetable {
    public String getInfo ();
}