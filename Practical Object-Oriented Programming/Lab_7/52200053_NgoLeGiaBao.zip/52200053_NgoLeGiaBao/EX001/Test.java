public class Test {
    public static void main (String [] args) {
        Shape shp1 = new Rectangle(5,3, "Yellow");
        Shape shp2 = new Triangle(3,4,"Blue");

        System.out.println (shp1);
        System.out.println(shp2);
    }
}
