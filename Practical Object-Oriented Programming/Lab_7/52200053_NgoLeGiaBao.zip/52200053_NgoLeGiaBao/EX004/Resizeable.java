public interface Resizeable {
    public void resize (double percent);
}