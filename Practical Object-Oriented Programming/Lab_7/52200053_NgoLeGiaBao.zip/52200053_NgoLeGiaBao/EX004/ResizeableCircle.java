public class ResizeableCircle extends Circle implements Resizeable {
     public void resize (double percent) {
        this.radius = percent;
     }
}