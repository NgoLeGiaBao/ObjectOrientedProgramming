public interface ChietKhau {
    public double tinhChietKhau ();
}